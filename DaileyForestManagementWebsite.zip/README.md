# Dailey Forest Management Website

Replace images/hero.jpg with your forest/map banner.
Upload these files to GitHub Pages, Netlify, or Cloudflare Pages.
